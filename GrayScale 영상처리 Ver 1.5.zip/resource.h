﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// GrayScaleImageProcessingBeta1.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_GrayScaleImageProcessingBeta1TYPE 130
#define IDD_DIALOG1                     312
#define IDD_CONSTANT                    314
#define IDD_CONSTANT2                   316
#define IDD_CONSTANT3                   317
#define IDD_CONSTANT4                   318
#define IDCANCEL                        1011
#define IDC_EDIT_CONSTANT               1015
#define IDC_EDIT_CONSTANT2              1017
#define IDC_EDIT_CONSTANT3              1018
#define IDC_EDIT_CONSTANT4              1019
#define IDM_EQUAL_IMAGE                 32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define IDM_DARK__IMAGE                 32775
#define ID_32776                        32776
#define IDM_GRAY_IMAGE                  32777
#define ID_32778                        32778
#define IDM_REVERSE_IMAGE               32779
#define ID_32780                        32780
#define ID_32781                        32781
#define IDM_ADD_IMAGE                   32782
#define ID_32783                        32783
#define IDM_DARK_IMAGE                  32784
#define ID_32785                        32785
#define IDM_GAMMA_IMAGE                 32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define IDM_PARABOL_CAP                 32790
#define IDM_PARABOL_CUP                 32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796
#define IDM_AND_IMAGE                   32797
#define IDM_OR_IMAGE                    32798
#define IDM_XOR_IMAGE                   32799
#define IDM_NOT_IMAGE                   32800
#define ID_32801                        32801
#define ID_32802                        32802
#define ID_32803                        32803
#define ID_32804                        32804
#define IDM_EM                          32805
#define IDM_EMBOSS                      32806
#define IDM_EMBOSS_IMAGE                32807
#define IDM_BLUR                        32808
#define IDM_SHARP                       32809
#define IDM_EDGE1                       32810
#define ID_32811                        32811
#define ID_32812                        32812
#define ID_32813                        32813
#define ID_32814                        32814
#define ID_32815                        32815
#define ID_32816                        32816
#define ID_32817                        32817
#define ID_32818                        32818
#define ID_32819                        32819
#define ID_32820                        32820
#define ID_32821                        32821
#define ID_32822                        32822
#define ID_32823                        32823
#define ID_32824                        32824
#define ID_32825                        32825
#define ID_32826                        32826
#define IDM_ZOOMIN                      32827
#define IDM_ZOOMIN2                     32828
#define IDM_ZOOMIN1                     32829
#define IDM_ZOOMIN3                     32830
#define IDM_ZOOMOUT                     32831
#define IDM_MOVE                        32832
#define IDM_ROTATE1                     32833
#define IDM_ROTATE2                     32834
#define IDM_ROTATE3                     32835
#define IDM_REVERSE1                    32836
#define IDM_REVERSE2                    32837
#define IDM_HISTO_STRETCH               32838
#define IDM_END_IN                      32839
#define IDM_HISTO_EQUAL                 32840
#define IDM_ZOOM_IN1                    32841
#define IDM_ZOOM_IN2                    32842
#define IDM_ZOOM_IN3                    32843
#define IDM_ZOOM_OUT                    32844
#define ID_32845                        32845
#define IDM_YAMMY                       32846

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        320
#define _APS_NEXT_COMMAND_VALUE         32847
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
